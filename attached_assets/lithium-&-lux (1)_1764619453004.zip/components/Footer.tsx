import React from 'react';
import { Diamond, Twitter, Linkedin, Github } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-stone-50 dark:bg-stone-950 border-t border-stone-200 dark:border-stone-800 pt-20 pb-10 transition-colors duration-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center space-x-2 mb-6">
              <Diamond className="w-5 h-5 text-gold-500" />
              <span className="text-lg font-serif font-bold tracking-wider text-stone-900 dark:text-stone-100">
                LITHIUM <span className="text-gold-500">&</span> LUX
              </span>
            </div>
            <p className="text-stone-500 dark:text-stone-400 text-sm leading-relaxed">
              The premier digital destination for the lithium industry's most influential players. Connecting capital, technology, and resources.
            </p>
          </div>
          
          <div>
            <h4 className="text-stone-900 dark:text-stone-200 font-serif mb-6">Directory</h4>
            <ul className="space-y-3 text-sm text-stone-500 dark:text-stone-400">
              <li className="hover:text-gold-600 dark:hover:text-gold-500 cursor-pointer transition-colors">Mining Companies</li>
              <li className="hover:text-gold-600 dark:hover:text-gold-500 cursor-pointer transition-colors">Refining Technology</li>
              <li className="hover:text-gold-600 dark:hover:text-gold-500 cursor-pointer transition-colors">Battery Manufacturers</li>
              <li className="hover:text-gold-600 dark:hover:text-gold-500 cursor-pointer transition-colors">Investment Firms</li>
            </ul>
          </div>

          <div>
            <h4 className="text-stone-900 dark:text-stone-200 font-serif mb-6">Resources</h4>
            <ul className="space-y-3 text-sm text-stone-500 dark:text-stone-400">
              <li className="hover:text-gold-600 dark:hover:text-gold-500 cursor-pointer transition-colors">Market Analysis</li>
              <li className="hover:text-gold-600 dark:hover:text-gold-500 cursor-pointer transition-colors">Sustainability Reports</li>
              <li className="hover:text-gold-600 dark:hover:text-gold-500 cursor-pointer transition-colors">AI Studio Guide</li>
              <li className="hover:text-gold-600 dark:hover:text-gold-500 cursor-pointer transition-colors">API Access</li>
            </ul>
          </div>

          <div>
            <h4 className="text-stone-900 dark:text-stone-200 font-serif mb-6">Connect</h4>
            <div className="flex space-x-4 mb-6">
              <a href="#" className="text-stone-400 hover:text-gold-600 transition-colors"><Twitter className="w-5 h-5" /></a>
              <a href="#" className="text-stone-400 hover:text-gold-600 transition-colors"><Linkedin className="w-5 h-5" /></a>
              <a href="#" className="text-stone-400 hover:text-gold-600 transition-colors"><Github className="w-5 h-5" /></a>
            </div>
            <div className="text-sm text-stone-400 dark:text-stone-500">
              <p>New York • London • Perth</p>
            </div>
          </div>
        </div>

        <div className="border-t border-stone-200 dark:border-stone-800 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-stone-500 dark:text-stone-500">
          <p>&copy; 2024 Lithium & Lux. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-gold-600 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-gold-600 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};