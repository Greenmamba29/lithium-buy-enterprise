import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline';
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  fullWidth = false, 
  className = '', 
  disabled,
  ...props 
}) => {
  const baseStyles = "inline-flex items-center justify-center px-6 py-3 text-sm font-medium tracking-wide transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gold-500 focus:ring-offset-stone-50 dark:focus:ring-offset-stone-950";
  
  const variants = {
    primary: "bg-gold-500 text-white hover:bg-gold-600 font-semibold shadow-[0_4px_14px_0_rgba(221,168,38,0.39)] hover:shadow-[0_6px_20px_rgba(221,168,38,0.23)] hover:-translate-y-0.5",
    secondary: "bg-stone-200 text-stone-900 hover:bg-stone-300 dark:bg-stone-800 dark:text-stone-100 dark:hover:bg-stone-700 hover:-translate-y-0.5",
    outline: "border border-gold-600 text-gold-700 dark:text-gold-500 hover:border-gold-700 dark:hover:border-gold-400 hover:bg-gold-50 dark:hover:bg-gold-900/10"
  };

  const widthStyle = fullWidth ? "w-full" : "";

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${widthStyle} ${className}`}
      disabled={disabled}
      {...props}
    >
      {children}
    </button>
  );
};