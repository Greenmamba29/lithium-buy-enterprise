import React from 'react';
import { Button } from './Button';
import { ArrowRight } from 'lucide-react';

interface HeroProps {
  onCtaClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onCtaClick }) => {
  return (
    <div className="relative h-[80vh] min-h-[600px] flex items-center justify-center overflow-hidden bg-stone-100 dark:bg-stone-900 transition-colors duration-500">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1518544806314-5f817362df58?q=80&w=2070&auto=format&fit=crop"
          alt="Abstract metallic texture" 
          className="w-full h-full object-cover opacity-10 dark:opacity-20 grayscale-[20%]"
        />
        {/* Gradient overlays to fade into stone background */}
        <div className="absolute inset-0 bg-gradient-to-t from-stone-50 via-stone-50/40 to-transparent dark:from-stone-950 dark:via-stone-950/40" />
        <div className="absolute inset-0 bg-gradient-to-r from-stone-50/80 via-transparent to-transparent dark:from-stone-950/80" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center md:text-left w-full">
        <div className="max-w-3xl">
          <h2 className="text-gold-600 tracking-[0.2em] text-sm font-bold uppercase mb-4 animate-fade-in">
            The Global Standard
          </h2>
          <h1 className="text-5xl md:text-7xl font-serif font-bold text-stone-900 dark:text-stone-100 mb-6 leading-tight transition-colors duration-500">
            Curating the Future of <span className="text-transparent bg-clip-text bg-gradient-to-r from-gold-600 to-stone-500 dark:to-stone-300">Lithium</span>
          </h1>
          <p className="text-xl text-stone-600 dark:text-stone-400 mb-10 max-w-xl font-light leading-relaxed transition-colors duration-500">
            Discover the world's most exclusive lithium mining enterprises, technology innovators, and investment opportunities in one pristine directory.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
            <Button onClick={onCtaClick}>
              Explore Directory
            </Button>
            <Button variant="secondary" onClick={() => document.getElementById('studio-section')?.scrollIntoView({ behavior: 'smooth' })}>
              Try AI Studio <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};