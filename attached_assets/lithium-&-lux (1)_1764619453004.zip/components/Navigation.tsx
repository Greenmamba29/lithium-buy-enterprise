import React, { useState, useEffect } from 'react';
import { Menu, X, Diamond, Moon, Sun } from 'lucide-react';

interface NavigationProps {
  activeSection: string;
  onNavigate: (section: string) => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeSection, onNavigate, isDarkMode, toggleTheme }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'directory', label: 'Directory' },
    { id: 'studio', label: 'AI Studio' },
    { id: 'market', label: 'Market Data' },
    { id: 'about', label: 'About' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white/90 dark:bg-stone-950/90 backdrop-blur-md border-b border-stone-200 dark:border-stone-800 py-4 shadow-sm' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          
          {/* Logo */}
          <div className="flex items-center space-x-2 cursor-pointer group" onClick={() => onNavigate('directory')}>
            <Diamond className="w-6 h-6 text-gold-500 transition-transform duration-500 group-hover:rotate-180" />
            <span className={`text-xl font-serif font-bold tracking-wider transition-colors ${isScrolled ? 'text-stone-900 dark:text-stone-100' : 'text-stone-900 dark:text-stone-100'}`}>
              LITHIUM <span className="text-gold-500">&</span> LUX
            </span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`text-sm tracking-widest uppercase transition-colors duration-300 ${
                  activeSection === item.id 
                    ? 'text-gold-600 border-b border-gold-500' 
                    : 'text-stone-500 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100'
                }`}
              >
                {item.label}
              </button>
            ))}
            
            <button 
              onClick={toggleTheme}
              className="p-2 text-stone-500 hover:text-gold-600 dark:text-stone-400 dark:hover:text-gold-500 transition-colors"
              aria-label="Toggle Dark Mode"
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            <button className="px-5 py-2 text-xs font-bold tracking-widest text-white bg-stone-900 dark:bg-stone-100 dark:text-stone-900 hover:bg-gold-600 dark:hover:bg-gold-500 hover:text-white transition-colors uppercase shadow-lg">
              Join Network
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-4">
            <button 
              onClick={toggleTheme}
              className="p-2 text-stone-500 dark:text-stone-400"
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="text-stone-900 dark:text-stone-100">
              {isMobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white dark:bg-stone-900 border-b border-stone-100 dark:border-stone-800 absolute top-full left-0 right-0 p-4 shadow-xl">
          <div className="flex flex-col space-y-4">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  setIsMobileMenuOpen(false);
                }}
                className={`text-left text-sm tracking-widest uppercase py-2 ${
                  activeSection === item.id ? 'text-gold-600' : 'text-stone-500 dark:text-stone-400'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};