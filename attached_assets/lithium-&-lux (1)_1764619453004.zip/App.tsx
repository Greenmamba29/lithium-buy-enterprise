import React, { useState, useEffect } from 'react';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { DirectoryGrid } from './components/DirectoryGrid';
import { ImageEditor } from './components/ImageEditor';
import { Footer } from './components/Footer';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState('directory');
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    
    // Smooth scroll handling
    if (sectionId === 'directory') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (sectionId === 'studio') {
      document.getElementById('studio-section')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className={`min-h-screen font-sans selection:bg-gold-200 selection:text-stone-900 transition-colors duration-300 ${isDarkMode ? 'dark bg-stone-950 text-stone-100' : 'bg-stone-50 text-stone-900'}`}>
      <Navigation 
        activeSection={activeSection} 
        onNavigate={scrollToSection} 
        isDarkMode={isDarkMode}
        toggleTheme={toggleTheme}
      />
      
      <main>
        <Hero onCtaClick={() => scrollToSection('directory')} />
        
        {/* We keep all components mounted for a seamless single-page feel, using scroll to navigate */}
        <div id="directory-section">
          <DirectoryGrid />
        </div>
        
        <ImageEditor />
      </main>

      <Footer />
    </div>
  );
};

export default App;