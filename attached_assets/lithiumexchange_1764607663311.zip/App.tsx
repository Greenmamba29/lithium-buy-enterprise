import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Discovery from './pages/Discovery';
import SupplierProfile from './pages/SupplierProfile';
import Telebuy from './pages/Telebuy';

const App = () => {
  return (
    <Router>
      <div className="min-h-screen flex flex-col font-sans text-gray-900">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Discovery />} />
            <Route path="/supplier/:id" element={<SupplierProfile />} />
            <Route path="/telebuy/:id" element={<Telebuy />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
};

export default App;