import { Supplier } from './types';

const generateReviews = (count: number): any[] => {
  return Array.from({ length: count }).map((_, i) => ({
    id: `rev-${i}`,
    author: `Procurement Officer ${i + 1}`,
    rating: 4 + Math.random(),
    date: '2023-10-15',
    comment: 'Excellent quality and timely delivery. Documentation was perfect.',
  }));
};

export const MOCK_SUPPLIERS: Supplier[] = [
  {
    id: '1',
    name: 'Apex Lithium Materials',
    location: 'Perth, Australia',
    tier: 'Gold',
    rating: 4.9,
    transactionCount: 1420,
    joinedYear: 2018,
    logoUrl: 'https://picsum.photos/seed/apex/200',
    description: 'Premier supplier of battery-grade lithium hydroxide and carbonate. Fully vertically integrated supply chain ensuring consistent purity and reliability for EV battery manufacturers.',
    responseTime: '< 2 hrs',
    tags: ['Hydroxide', 'Carbonate'],
    certs: ['ISO 9001', 'ISO 14001', 'Responsible Mining'],
    products: [
      { name: 'Battery Grade Lithium Hydroxide', purity: '99.9%', pricePerTon: 28500, availableQuantity: 500, moq: 10 },
      { name: 'Technical Grade Lithium Carbonate', purity: '99.5%', pricePerTon: 24000, availableQuantity: 1200, moq: 20 },
    ],
    reviews: generateReviews(5)
  },
  {
    id: '2',
    name: 'Andean Brine Solutions',
    location: 'Antofagasta, Chile',
    tier: 'Gold',
    rating: 4.8,
    transactionCount: 890,
    joinedYear: 2019,
    logoUrl: 'https://picsum.photos/seed/andean/200',
    description: 'Sustainable lithium extraction from the Atacama salt flats. We prioritize water conservation technologies and community engagement while delivering high-purity lithium carbonate.',
    responseTime: '< 4 hrs',
    tags: ['Carbonate', 'Raw Lithium'],
    certs: ['ISO 9001', 'Fair Trade Minerals'],
    products: [
      { name: 'Lithium Carbonate Standard', purity: '99.2%', pricePerTon: 22000, availableQuantity: 2000, moq: 50 },
    ],
    reviews: generateReviews(3)
  },
  {
    id: '3',
    name: 'Sino-Global Resources',
    location: 'Shanghai, China',
    tier: 'Silver',
    rating: 4.6,
    transactionCount: 3200,
    joinedYear: 2015,
    logoUrl: 'https://picsum.photos/seed/sino/200',
    description: 'Large-scale processor of spodumene concentrate. Connecting global mines with advanced processing capabilities to deliver battery-ready materials.',
    responseTime: '< 1 hr',
    tags: ['Spodumene', 'Hydroxide'],
    certs: ['CNAS Accredited'],
    products: [
      { name: 'Spodumene Concentrate', purity: 'SC 6.0', pricePerTon: 3200, availableQuantity: 10000, moq: 100 },
      { name: 'Lithium Hydroxide Monohydrate', purity: '56.5% LiOH', pricePerTon: 27800, availableQuantity: 300, moq: 5 },
    ],
    reviews: generateReviews(8)
  },
  {
    id: '4',
    name: 'Nevada Green Energy Metals',
    location: 'Nevada, USA',
    tier: 'Silver',
    rating: 4.5,
    transactionCount: 150,
    joinedYear: 2021,
    logoUrl: 'https://picsum.photos/seed/nevada/200',
    description: 'Domestic US lithium source focused on supply chain security for North American manufacturers. Sedimentary clay extraction projects.',
    responseTime: '24 hrs',
    tags: ['Processed Ore', 'Raw Lithium'],
    certs: ['US EPA Compliant'],
    products: [
      { name: 'Lithium Enriched Clay', purity: 'Raw', pricePerTon: 1500, availableQuantity: 5000, moq: 500 },
    ],
    reviews: generateReviews(2)
  },
  {
    id: '5',
    name: 'Quebec Lithium Corp',
    location: 'Quebec, Canada',
    tier: 'Bronze',
    rating: 4.2,
    transactionCount: 85,
    joinedYear: 2022,
    logoUrl: 'https://picsum.photos/seed/quebec/200',
    description: 'Hard rock lithium mining in the Canadian Shield. Focused on spodumene pegmatites.',
    responseTime: '48 hrs',
    tags: ['Spodumene'],
    certs: [],
    products: [
      { name: 'Spodumene Ore', purity: 'Unprocessed', pricePerTon: 900, availableQuantity: 2000, moq: 200 },
    ],
    reviews: generateReviews(1)
  },
   {
    id: '6',
    name: 'Volt Materials',
    location: 'Berlin, Germany',
    tier: 'Gold',
    rating: 4.9,
    transactionCount: 560,
    joinedYear: 2020,
    logoUrl: 'https://picsum.photos/seed/volt/200',
    description: 'European hub for battery recycling and lithium recovery. Circular economy specialists.',
    responseTime: '< 3 hrs',
    tags: ['Hydroxide', 'Carbonate'],
    certs: ['EU Green Deal Compliant', 'ISO 14001'],
    products: [
      { name: 'Recycled Lithium Carbonate', purity: '99.5%', pricePerTon: 25000, availableQuantity: 150, moq: 5 },
    ],
    reviews: generateReviews(4)
  }
];