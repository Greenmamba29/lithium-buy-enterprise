import React from 'react';
import { Link } from 'react-router-dom';
import { Layers, Bell, User, Search } from 'lucide-react';

const Header = () => {
  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center">
            <Link to="/" className="flex items-center gap-2">
              <div className="bg-primary p-1.5 rounded-lg">
                <Layers className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold text-primary tracking-tight">LithiumExchange</span>
            </Link>
            <div className="hidden md:flex ml-10 space-x-8">
              <Link to="/" className="text-gray-900 font-medium hover:text-primary transition-colors">Marketplace</Link>
              <a href="#" className="text-gray-500 hover:text-primary transition-colors">Intelligence</a>
              <a href="#" className="text-gray-500 hover:text-primary transition-colors">Logistics</a>
              <a href="#" className="text-gray-500 hover:text-primary transition-colors">Finance</a>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center bg-gray-100 px-3 py-1.5 rounded-full border border-gray-200">
               <Search className="h-4 w-4 text-gray-400 mr-2" />
               <input type="text" placeholder="Quick search..." className="bg-transparent text-sm outline-none w-32 focus:w-48 transition-all" />
            </div>
            <button className="p-2 text-gray-400 hover:text-primary transition-colors relative">
              <Bell className="h-5 w-5" />
              <span className="absolute top-1.5 right-1.5 h-2 w-2 bg-red-500 rounded-full"></span>
            </button>
            <button className="flex items-center gap-2 pl-2 border-l border-gray-200">
              <div className="h-8 w-8 bg-gray-200 rounded-full flex items-center justify-center text-primary font-bold">
                JD
              </div>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Header;