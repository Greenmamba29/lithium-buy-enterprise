import React from 'react';
import { Supplier } from '../types';
import { ShieldCheck, Star, MapPin, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface SupplierCardProps {
  supplier: Supplier;
  selected: boolean;
  onCompareToggle: (id: string) => void;
}

const SupplierCard: React.FC<SupplierCardProps> = ({ supplier, selected, onCompareToggle }) => {
  const minPrice = Math.min(...supplier.products.map(p => p.pricePerTon));
  
  return (
    <div className="group bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-xl hover:border-primary/30 hover:scale-[1.02] transition-all duration-300 flex flex-col h-full overflow-hidden">
      <div className="p-5 flex-1">
        <div className="flex justify-between items-start mb-4">
          <div className="flex gap-3">
             <div className="h-12 w-12 rounded-lg bg-gray-50 overflow-hidden border border-gray-100">
               <img src={supplier.logoUrl} alt={supplier.name} className="h-full w-full object-cover" />
             </div>
             <div>
               <h3 className="font-bold text-gray-900 leading-tight group-hover:text-primary transition-colors">{supplier.name}</h3>
               <div className="flex items-center gap-1 text-xs text-gray-500 mt-1">
                 <MapPin className="h-3 w-3" />
                 {supplier.location}
               </div>
             </div>
          </div>
          {supplier.tier === 'Gold' && (
            <div className="bg-gold/10 text-yellow-700 px-2 py-1 rounded-md text-xs font-semibold flex items-center gap-1 border border-gold/20">
              <ShieldCheck className="h-3 w-3 text-gold" />
              Verified
            </div>
          )}
          {supplier.tier === 'Silver' && (
            <div className="bg-gray-100 text-gray-600 px-2 py-1 rounded-md text-xs font-semibold flex items-center gap-1">
              <ShieldCheck className="h-3 w-3 text-gray-400" />
              Silver
            </div>
          )}
        </div>

        <div className="space-y-3 mb-4">
           <div className="flex justify-between items-center text-sm">
             <span className="text-gray-500">Rating</span>
             <div className="flex items-center gap-1">
               <Star className="h-3 w-3 text-gold fill-gold" />
               <span className="font-medium text-gray-900">{supplier.rating}</span>
               <span className="text-gray-400 text-xs">({supplier.reviews.length})</span>
             </div>
           </div>
           
           <div className="flex justify-between items-center text-sm">
             <span className="text-gray-500">Starting Price</span>
             <span className="font-medium text-gray-900">${minPrice.toLocaleString()}<span className="text-gray-400 text-xs font-normal">/ton</span></span>
           </div>

           <div className="flex flex-wrap gap-2 pt-2">
             {supplier.tags.slice(0, 3).map((tag, idx) => (
               <span key={idx} className="text-xs bg-surface text-gray-600 px-2 py-1 rounded border border-gray-100">{tag}</span>
             ))}
           </div>
        </div>
      </div>

      <div className="bg-gray-50 p-4 border-t border-gray-100 flex items-center justify-between">
        <div className="flex items-center gap-2">
           <input 
             type="checkbox" 
             id={`compare-${supplier.id}`}
             checked={selected}
             onChange={() => onCompareToggle(supplier.id)}
             className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary cursor-pointer" 
            />
           <label htmlFor={`compare-${supplier.id}`} className="text-xs font-medium text-gray-600 cursor-pointer select-none">Compare</label>
        </div>
        <Link to={`/supplier/${supplier.id}`} className="text-sm font-semibold text-primary flex items-center gap-1 hover:gap-2 transition-all">
          View Profile <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
};

export default SupplierCard;