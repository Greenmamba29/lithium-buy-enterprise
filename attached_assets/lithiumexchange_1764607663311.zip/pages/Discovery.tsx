import React, { useState, useMemo } from 'react';
import { Search, Filter, X, ArrowUpDown, ChevronDown } from 'lucide-react';
import SupplierCard from '../components/SupplierCard';
import { MOCK_SUPPLIERS } from '../data';
import { Supplier, ProductType, VerificationTier } from '../types';

const Discovery = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTypes, setSelectedTypes] = useState<ProductType[]>([]);
  const [selectedTiers, setSelectedTiers] = useState<VerificationTier[]>([]);
  const [comparisonIds, setComparisonIds] = useState<string[]>([]);

  // Filter Logic
  const filteredSuppliers = useMemo(() => {
    return MOCK_SUPPLIERS.filter(supplier => {
      const matchesSearch = supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            supplier.tags.some(t => t.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchesType = selectedTypes.length === 0 || supplier.tags.some(tag => selectedTypes.includes(tag));
      const matchesTier = selectedTiers.length === 0 || selectedTiers.includes(supplier.tier);

      return matchesSearch && matchesType && matchesTier;
    });
  }, [searchTerm, selectedTypes, selectedTiers]);

  const toggleComparison = (id: string) => {
    setComparisonIds(prev => 
      prev.includes(id) ? prev.filter(curr => curr !== id) : [...prev, id]
    );
  };

  const toggleType = (type: ProductType) => {
    setSelectedTypes(prev => 
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  const toggleTier = (tier: VerificationTier) => {
    setSelectedTiers(prev => 
      prev.includes(tier) ? prev.filter(t => t !== tier) : [...prev, tier]
    );
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Hero Search Section */}
      <div className="bg-primary pt-12 pb-24 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-white/5 skew-x-12 transform translate-x-20 pointer-events-none"></div>
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-6 tracking-tight">
            Find Verified Lithium Suppliers
          </h1>
          <p className="text-blue-100 text-lg mb-8 max-w-2xl mx-auto">
            Access the global directory of audited mining companies and processors. Compare prices, purity, and availability in real-time.
          </p>
          
          <div className="bg-white rounded-lg shadow-xl p-2 flex flex-col md:flex-row gap-2 max-w-2xl mx-auto">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input 
                type="text" 
                className="w-full h-11 pl-10 pr-4 rounded-md text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary/20"
                placeholder="Search by product, company, or chemical formula..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <button className="bg-gold hover:bg-yellow-500 text-primary font-bold py-2 px-8 rounded-md transition-colors whitespace-nowrap">
              Search Market
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-12 relative z-20">
        <div className="flex flex-col lg:flex-row gap-8">
          
          {/* Filters Sidebar */}
          <div className="w-full lg:w-64 flex-shrink-0">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sticky top-24">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-bold text-gray-900 flex items-center gap-2">
                  <Filter className="h-4 w-4" /> Filters
                </h2>
                {(selectedTypes.length > 0 || selectedTiers.length > 0) && (
                  <button 
                    onClick={() => {setSelectedTypes([]); setSelectedTiers([]);}}
                    className="text-xs text-primary font-medium hover:underline"
                  >
                    Reset
                  </button>
                )}
              </div>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-xs font-semibold uppercase text-gray-500 mb-3 tracking-wider">Product Type</h3>
                  <div className="space-y-2">
                    {['Raw Lithium', 'Carbonate', 'Hydroxide', 'Spodumene'].map((type) => (
                      <label key={type} className="flex items-center gap-2 cursor-pointer group">
                        <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${selectedTypes.includes(type as ProductType) ? 'bg-primary border-primary' : 'border-gray-300 bg-white group-hover:border-primary'}`}>
                          {selectedTypes.includes(type as ProductType) && <div className="w-2 h-2 bg-white rounded-sm" />}
                        </div>
                        <input 
                          type="checkbox" 
                          className="hidden" 
                          checked={selectedTypes.includes(type as ProductType)}
                          onChange={() => toggleType(type as ProductType)}
                        />
                        <span className="text-sm text-gray-700 group-hover:text-primary transition-colors">{type}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="border-t border-gray-100 pt-6">
                  <h3 className="text-xs font-semibold uppercase text-gray-500 mb-3 tracking-wider">Verification</h3>
                  <div className="space-y-2">
                    {['Gold', 'Silver', 'Bronze'].map((tier) => (
                      <label key={tier} className="flex items-center gap-2 cursor-pointer group">
                         <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${selectedTiers.includes(tier as VerificationTier) ? 'bg-primary border-primary' : 'border-gray-300 bg-white group-hover:border-primary'}`}>
                          {selectedTiers.includes(tier as VerificationTier) && <div className="w-2 h-2 bg-white rounded-sm" />}
                        </div>
                        <input 
                          type="checkbox" 
                          className="hidden"
                          checked={selectedTiers.includes(tier as VerificationTier)}
                          onChange={() => toggleTier(tier as VerificationTier)}
                        />
                        <span className="text-sm text-gray-700">{tier} Tier</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Results Grid */}
          <div className="flex-1">
             <div className="flex justify-between items-center mb-4 text-sm bg-white p-3 rounded-lg border border-gray-200 shadow-sm">
               <span className="text-gray-500">Showing <strong className="text-gray-900">{filteredSuppliers.length}</strong> suppliers</span>
               <div className="flex items-center gap-2">
                 <span className="text-gray-500 hidden sm:inline">Sort by:</span>
                 <button className="flex items-center gap-1 font-medium text-gray-700 hover:text-primary">
                   Most Verified <ChevronDown className="h-4 w-4" />
                 </button>
               </div>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
               {filteredSuppliers.map(supplier => (
                 <SupplierCard 
                    key={supplier.id} 
                    supplier={supplier} 
                    selected={comparisonIds.includes(supplier.id)}
                    onCompareToggle={toggleComparison}
                 />
               ))}
             </div>

             {filteredSuppliers.length === 0 && (
               <div className="text-center py-20 bg-white rounded-xl border border-dashed border-gray-300 mt-4">
                 <Filter className="h-10 w-10 text-gray-300 mx-auto mb-4" />
                 <h3 className="text-lg font-medium text-gray-900">No suppliers found</h3>
                 <p className="text-gray-500">Try adjusting your filters or search term.</p>
               </div>
             )}
          </div>
        </div>
      </div>

      {/* Comparison Floating Bar */}
      {comparisonIds.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gold shadow-[0_-4px_20px_rgba(0,0,0,0.1)] z-50 p-4 transform transition-transform duration-300">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span className="font-bold text-gray-900">{comparisonIds.length} Suppliers Selected</span>
              <div className="hidden sm:flex -space-x-2">
                 {comparisonIds.slice(0, 4).map(id => {
                   const s = MOCK_SUPPLIERS.find(s => s.id === id);
                   return s ? (
                     <img key={id} src={s.logoUrl} alt={s.name} className="h-8 w-8 rounded-full border-2 border-white" />
                   ) : null
                 })}
              </div>
            </div>
            <div className="flex items-center gap-4">
              <button 
                onClick={() => setComparisonIds([])}
                className="text-gray-500 hover:text-red-500 text-sm font-medium"
              >
                Clear All
              </button>
              <button className="bg-primary hover:bg-blue-900 text-white px-6 py-2 rounded-md font-semibold flex items-center gap-2 transition-colors shadow-lg shadow-primary/30">
                <ArrowUpDown className="h-4 w-4" /> Compare Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Discovery;