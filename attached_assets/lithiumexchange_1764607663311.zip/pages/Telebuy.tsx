import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { MOCK_SUPPLIERS } from '../data';
import { Video, Calendar, CheckCircle, Shield, FileSignature, CreditCard, Lock } from 'lucide-react';

const Telebuy = () => {
  const { id } = useParams<{ id: string }>();
  const supplier = MOCK_SUPPLIERS.find(s => s.id === id);
  const [step, setStep] = useState(1);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');

  if (!supplier) return null;

  const steps = [
    { num: 1, title: 'Schedule Call', icon: Calendar },
    { num: 2, title: 'Sign NDA', icon: FileSignature },
    { num: 3, title: 'Secure Payment', icon: CreditCard }
  ];

  return (
    <div className="min-h-screen bg-surface pb-20">
      <div className="bg-primary pb-24 pt-12">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-3xl font-bold text-white mb-2">Telebuy Secure Room</h1>
          <p className="text-blue-100">Initiating secure transaction with {supplier.name}</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 -mt-16">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden flex flex-col md:flex-row min-h-[500px]">
          
          {/* Sidebar Steps */}
          <div className="bg-gray-50 border-r border-gray-100 w-full md:w-64 p-6">
            <div className="space-y-8">
              {steps.map((s) => (
                <div key={s.num} className={`flex items-start gap-4 ${step === s.num ? 'opacity-100' : 'opacity-40'}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0 transition-colors ${step >= s.num ? 'bg-primary text-white' : 'bg-gray-200 text-gray-500'}`}>
                    {step > s.num ? <CheckCircle className="h-5 w-5" /> : s.num}
                  </div>
                  <div className="mt-1">
                    <p className={`font-semibold text-sm ${step === s.num ? 'text-primary' : 'text-gray-900'}`}>{s.title}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {s.num === 1 && 'Select available slot'}
                      {s.num === 2 && 'Review terms'}
                      {s.num === 3 && 'Escrow setup'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-12 bg-blue-50 p-4 rounded-lg border border-blue-100">
              <div className="flex items-center gap-2 text-primary font-bold text-sm mb-2">
                <Shield className="h-4 w-4" /> Secure Guarantee
              </div>
              <p className="text-xs text-blue-800 leading-snug">
                All Telebuy sessions are recorded and contracts are legally binding via DocuSign integration.
              </p>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="flex-1 p-8 md:p-10">
            {step === 1 && (
              <div className="animate-in fade-in duration-500">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Schedule Video Inspection</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                   <div>
                     <label className="block text-sm font-medium text-gray-700 mb-2">Select Date</label>
                     <input 
                       type="date" 
                       className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary/20 outline-none"
                       onChange={(e) => setDate(e.target.value)}
                      />
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 mb-2">Select Time (UTC)</label>
                     <select 
                       className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary/20 outline-none"
                       onChange={(e) => setTime(e.target.value)}
                     >
                       <option>Select time...</option>
                       <option>09:00 AM</option>
                       <option>10:00 AM</option>
                       <option>02:00 PM</option>
                       <option>04:00 PM</option>
                     </select>
                   </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-xl border border-dashed border-gray-300 text-center mb-8">
                  <Video className="h-10 w-10 text-gray-400 mx-auto mb-3" />
                  <p className="text-sm text-gray-600">Video link will be generated via Zoom Integration upon confirmation.</p>
                </div>

                <button 
                  disabled={!date || !time}
                  onClick={() => setStep(2)}
                  className="w-full bg-primary disabled:opacity-50 disabled:cursor-not-allowed hover:bg-blue-900 text-white font-bold py-3 rounded-lg shadow-md transition-all"
                >
                  Confirm Slot & Continue
                </button>
              </div>
            )}

            {step === 2 && (
              <div className="animate-in fade-in duration-500">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Review & Sign NDA</h2>
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 h-64 overflow-y-auto mb-6 text-sm text-gray-600 font-mono">
                  <p className="mb-4">NON-DISCLOSURE AGREEMENT (Standard LithiumExchange Template v2.1)</p>
                  <p className="mb-4">This Agreement is made between {supplier.name} ("Disclosing Party") and the User ("Receiving Party")...</p>
                  <p>1. Purpose: The parties wish to explore a business opportunity regarding the purchase of lithium materials...</p>
                  <p className="mt-4">[... Full legal text placeholder ...]</p>
                </div>
                
                <div className="flex items-center gap-3 mb-8">
                  <input type="checkbox" id="agree" className="w-5 h-5 text-primary rounded border-gray-300" />
                  <label htmlFor="agree" className="text-sm text-gray-700">I have read and agree to the Non-Disclosure Agreement</label>
                </div>

                <button 
                  onClick={() => setStep(3)}
                  className="w-full bg-primary hover:bg-blue-900 text-white font-bold py-3 rounded-lg shadow-md transition-all flex justify-center items-center gap-2"
                >
                  <FileSignature className="h-5 w-5" /> Digitally Sign via DocuSign
                </button>
                <button onClick={() => setStep(1)} className="w-full mt-3 text-gray-500 text-sm hover:text-gray-900">Back</button>
              </div>
            )}

            {step === 3 && (
               <div className="animate-in fade-in duration-500 text-center">
                 <div className="bg-green-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                   <Lock className="h-10 w-10 text-green-600" />
                 </div>
                 <h2 className="text-2xl font-bold text-gray-900 mb-2">Ready to Transact</h2>
                 <p className="text-gray-500 mb-8">Meeting scheduled for {date} at {time}. Contract signed.</p>
                 
                 <div className="bg-white border border-gray-200 rounded-lg p-6 text-left mb-8 shadow-sm">
                   <h3 className="font-bold text-gray-900 mb-4 border-b pb-2">Estimated Transaction Fee</h3>
                   <div className="flex justify-between mb-2 text-sm">
                     <span className="text-gray-600">Marketplace Commission (3.5%)</span>
                     <span className="font-medium">$0.00 (Pending Quote)</span>
                   </div>
                   <div className="flex justify-between text-sm">
                     <span className="text-gray-600">Escrow Service Fee</span>
                     <span className="font-medium">$250.00</span>
                   </div>
                 </div>

                 <button className="w-full bg-gold hover:bg-yellow-500 text-primary font-bold py-3 rounded-lg shadow-md transition-all">
                   Authorize Payment Setup
                 </button>
               </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Telebuy;