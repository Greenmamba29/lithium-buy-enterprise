import React, { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MOCK_SUPPLIERS } from '../data';
import { ShieldCheck, Star, Clock, MapPin, Award, CheckCircle, Video, FileText } from 'lucide-react';

const SupplierProfile = () => {
  const { id } = useParams<{ id: string }>();
  const supplier = MOCK_SUPPLIERS.find(s => s.id === id);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  if (!supplier) {
    return <div className="p-10 text-center">Supplier not found</div>;
  }

  return (
    <div className="min-h-screen pb-20 bg-surface">
      {/* Header Info */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
           <div className="flex flex-col md:flex-row gap-6 items-start md:items-center">
             <div className="h-24 w-24 rounded-xl border border-gray-200 p-1 bg-white shadow-sm flex-shrink-0">
               <img src={supplier.logoUrl} alt={supplier.name} className="w-full h-full object-cover rounded-lg" />
             </div>
             <div className="flex-1">
               <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-2">
                 <h1 className="text-3xl font-bold text-gray-900">{supplier.name}</h1>
                 {supplier.tier === 'Gold' && (
                    <span className="inline-flex items-center gap-1 bg-gold/10 text-yellow-800 text-xs px-2 py-1 rounded-full font-semibold border border-gold/30">
                      <ShieldCheck className="h-3 w-3" /> Gold Verified
                    </span>
                 )}
               </div>
               <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
                 <span className="flex items-center gap-1"><MapPin className="h-4 w-4" /> {supplier.location}</span>
                 <span className="flex items-center gap-1"><Clock className="h-4 w-4" /> Responds in {supplier.responseTime}</span>
                 <span className="flex items-center gap-1"><Award className="h-4 w-4" /> Member since {supplier.joinedYear}</span>
               </div>
             </div>
             <div className="flex gap-3">
               <Link 
                 to={`/telebuy/${supplier.id}`}
                 className="flex items-center gap-2 bg-primary hover:bg-blue-900 text-white px-6 py-3 rounded-lg font-bold shadow-lg shadow-primary/20 transition-all transform hover:-translate-y-0.5"
               >
                 <Video className="h-5 w-5" /> Schedule Telebuy
               </Link>
             </div>
           </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* About */}
            <section className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-bold text-gray-900 mb-4">About the Company</h2>
              <p className="text-gray-600 leading-relaxed">{supplier.description}</p>
              
              <div className="mt-6 flex flex-wrap gap-2">
                {supplier.certs.map(cert => (
                  <span key={cert} className="inline-flex items-center gap-1.5 bg-green-50 text-green-700 px-3 py-1.5 rounded-full text-sm font-medium border border-green-100">
                    <CheckCircle className="h-4 w-4" /> {cert}
                  </span>
                ))}
              </div>
            </section>

            {/* Products Table */}
            <section className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-100">
                <h2 className="text-lg font-bold text-gray-900">Available Products</h2>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-gray-50 text-gray-500 uppercase tracking-wider font-semibold">
                    <tr>
                      <th className="px-6 py-4">Product Name</th>
                      <th className="px-6 py-4">Purity</th>
                      <th className="px-6 py-4">Availability</th>
                      <th className="px-6 py-4 text-right">Price/Ton</th>
                      <th className="px-6 py-4"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {supplier.products.map((product, idx) => (
                      <tr key={idx} className="hover:bg-blue-50/50 transition-colors">
                        <td className="px-6 py-4 font-medium text-gray-900">{product.name}</td>
                        <td className="px-6 py-4 text-gray-600">{product.purity}</td>
                        <td className="px-6 py-4">
                          <span className={`${product.availableQuantity > 1000 ? 'text-green-600' : 'text-yellow-600'} font-medium`}>
                            {product.availableQuantity.toLocaleString()} tons
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right font-bold text-gray-900">${product.pricePerTon.toLocaleString()}</td>
                        <td className="px-6 py-4 text-right">
                          <button className="text-primary hover:text-blue-800 font-medium text-xs border border-primary/20 px-3 py-1 rounded hover:bg-primary/5">
                            Details
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Reviews */}
            <section className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                Recent Reviews <span className="text-gray-400 font-normal text-sm">({supplier.reviews.length})</span>
              </h2>
              <div className="space-y-6">
                {supplier.reviews.map(review => (
                  <div key={review.id} className="border-b border-gray-100 last:border-0 pb-6 last:pb-0">
                    <div className="flex justify-between items-start mb-2">
                      <div className="font-semibold text-gray-900">{review.author}</div>
                      <span className="text-xs text-gray-400">{review.date}</span>
                    </div>
                    <div className="flex items-center gap-1 mb-2">
                       {Array.from({length: 5}).map((_, i) => (
                         <Star key={i} className={`h-3 w-3 ${i < Math.floor(review.rating) ? 'text-gold fill-gold' : 'text-gray-300'}`} />
                       ))}
                    </div>
                    <p className="text-gray-600 text-sm italic">"{review.comment}"</p>
                  </div>
                ))}
              </div>
            </section>

          </div>

          {/* Sidebar Stats */}
          <div className="space-y-6">
            <div className="bg-primary text-white rounded-xl p-6 shadow-lg">
              <h3 className="font-bold text-lg mb-4">Supplier Performance</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center border-b border-white/10 pb-2">
                  <span className="text-blue-200">Overall Rating</span>
                  <span className="text-xl font-bold text-gold">{supplier.rating}/5.0</span>
                </div>
                <div className="flex justify-between items-center border-b border-white/10 pb-2">
                   <span className="text-blue-200">Transactions</span>
                   <span className="font-bold">{supplier.transactionCount}</span>
                </div>
                <div className="flex justify-between items-center">
                   <span className="text-blue-200">Fulfillment Rate</span>
                   <span className="font-bold text-green-400">98.5%</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
               <h3 className="font-bold text-gray-900 mb-4">Verification Documents</h3>
               <ul className="space-y-3">
                 {['Business License', 'Export Permit', 'Quality Certs', 'Financial Audit'].map(doc => (
                   <li key={doc} className="flex items-center justify-between text-sm text-gray-600 group cursor-pointer">
                     <div className="flex items-center gap-2">
                       <FileText className="h-4 w-4 text-gray-400 group-hover:text-primary" />
                       <span className="group-hover:text-primary transition-colors">{doc}</span>
                     </div>
                     <span className="text-green-600 text-xs bg-green-50 px-2 py-0.5 rounded">Verified</span>
                   </li>
                 ))}
               </ul>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default SupplierProfile;