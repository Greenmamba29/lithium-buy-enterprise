export type VerificationTier = 'Gold' | 'Silver' | 'Bronze';

export type ProductType = 'Raw Lithium' | 'Carbonate' | 'Hydroxide' | 'Spodumene' | 'Processed Ore';

export interface ProductSpec {
  name: string;
  purity: string;
  pricePerTon: number;
  availableQuantity: number; // in Tons
  moq: number; // Minimum Order Quantity
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  date: string;
  comment: string;
}

export interface Supplier {
  id: string;
  name: string;
  location: string;
  tier: VerificationTier;
  rating: number;
  transactionCount: number;
  joinedYear: number;
  logoUrl: string;
  description: string;
  responseTime: string;
  products: ProductSpec[];
  tags: ProductType[];
  certs: string[];
  reviews: Review[];
}